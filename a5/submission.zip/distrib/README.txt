Did you collaborate with anyone in the class? - 

Were there any references (books, papers, websites, etc.) that you found particularly helpful for completing your assignment? Stackoverflow

Are there any known problems with your code? -

Did you do any extra credit? -

Comments? This assignment is challenging.
The ray tracing in scene10_sphere needs more than 4 bounces for the light to properly refract out of the sphere.