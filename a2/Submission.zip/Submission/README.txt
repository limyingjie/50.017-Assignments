Did you collaborate with anyone in the class? - 

Were there any references (books, papers, websites, etc.) that you found particularly helpful for completing your assignment?
Stackoverflow

Are there any known problems with your code? -

Got any comments about this assignment that you'd like to share? -