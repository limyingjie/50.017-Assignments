Did you collaborate with anyone in the class?
-

Were there any references (books, papers, websites, etc.) that you found particularly helpful for completing your assignment?
Stack Overflow

Are there any known problems with your code?
-

Did you do any extra credit?
-

Comments: Took quite a while to realize that we are redirecting the text of the object file into cin, instead of passing the filename as an argument. Could have highlighted this in the instructions.

Example usage: zero < garg.obj